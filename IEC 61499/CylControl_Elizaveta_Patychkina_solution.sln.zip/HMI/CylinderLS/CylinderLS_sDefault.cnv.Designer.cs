﻿/*
 * Created by nxtSTUDIO.
 * User: Andrei
 * Date: 5/26/2016
 * Time: 7:34 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace HMI.Main.Symbols.CylinderLS
{
	/// <summary>
	/// Summary description for sDefault.
	/// </summary>
	partial class sDefault
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.FB3 = new HMI.Main.Symbols.CylinderSA.sDefault();
			this.FB1 = new HMI.Main.Symbols.Valve.sDefault();
			// 
			// FB3
			// 
			this.FB3.BeginInit();
			this.FB3.AngleIgnore = false;
			this.FB3.DesignTransformation = new NxtControl.Drawing.Matrix(1, 0, 0, 1, 25, 59);
			this.FB3.Name = "FB3";
			this.FB3.SecurityToken = ((uint)(4294967295u));
			this.FB3.TagName = "FB3";
			this.FB3.EndInit();
			// 
			// FB1
			// 
			this.FB1.BeginInit();
			this.FB1.AngleIgnore = false;
			this.FB1.DesignTransformation = new NxtControl.Drawing.Matrix(1, 0, 0, 1, 38, 253);
			this.FB1.Name = "FB1";
			this.FB1.SecurityToken = ((uint)(4294967295u));
			this.FB1.TagName = "FB1";
			this.FB1.EndInit();
			// 
			// sDefault
			// 
			this.Name = "sDefault";
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
									this.FB3,
									this.FB1});
			this.SymbolSize = new System.Drawing.Size(800, 600);
		}
		private HMI.Main.Symbols.Valve.sDefault FB1;
		private HMI.Main.Symbols.CylinderSA.sDefault FB3;
		#endregion
	}
}
