﻿/*
 * Created by nxtSTUDIO.
 * User: Andrei
 * Date: 5/26/2016
 * Time: 8:11 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;

using NxtControl.GuiFramework;

namespace HMI.Main.Canvases
{
	/// <summary>
	/// Summary description for Canvas1.
	/// </summary>
	partial class Canvas1
	{
		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Cylinder = new HMI.Main.Symbols.CylinderLS.sDefault();
			this.polyline1 = new NxtControl.GuiFramework.Polyline();
			this.polyline2 = new NxtControl.GuiFramework.Polyline();
			this.rectangle1 = new NxtControl.GuiFramework.Rectangle();
			this.freeText1 = new NxtControl.GuiFramework.FreeText();
			this.START_BT = new HMI.Main.Symbols.CallButton.sDefault();
			this.freeText2 = new NxtControl.GuiFramework.FreeText();
			this.HMI1 = new HMI.Main.Symbols.CallButton.sDefault();
			this.freeText3 = new NxtControl.GuiFramework.FreeText();
			this.freeText5 = new NxtControl.GuiFramework.FreeText();
			this.Stop_Button = new HMI.Main.Symbols.CallButton.sDefault();
			this.freeText6 = new NxtControl.GuiFramework.FreeText();
			this.freeText7 = new NxtControl.GuiFramework.FreeText();
			// 
			// Cylinder
			// 
			this.Cylinder.BeginInit();
			this.Cylinder.AngleIgnore = false;
			this.Cylinder.DesignTransformation = new NxtControl.Drawing.Matrix(1D, 0D, 0D, 1D, 49D, 50D);
			this.Cylinder.Name = "Cylinder";
			this.Cylinder.SecurityToken = ((uint)(4294967295u));
			this.Cylinder.TagName = "416F91F5B47339F9";
			this.Cylinder.EndInit();
			// 
			// polyline1
			// 
			this.polyline1.Bounds = new NxtControl.Drawing.RectF(((float)(201D)), ((float)(167D)), ((float)(156D)), ((float)(76D)));
			this.polyline1.Closed = false;
			this.polyline1.Name = "polyline1";
			this.polyline1.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(0)), ((byte)(0)), ((byte)(0))), 8F, NxtControl.Drawing.DashStyle.Solid);
			this.polyline1.Points.AddRange(new NxtControl.Drawing.PointF[] {
									new NxtControl.Drawing.PointF(201D, 243D),
									new NxtControl.Drawing.PointF(201D, 206D),
									new NxtControl.Drawing.PointF(357D, 206D),
									new NxtControl.Drawing.PointF(357D, 167D)});
			// 
			// polyline2
			// 
			this.polyline2.Bounds = new NxtControl.Drawing.RectF(((float)(79D)), ((float)(167D)), ((float)(101D)), ((float)(76D)));
			this.polyline2.Closed = false;
			this.polyline2.Name = "polyline2";
			this.polyline2.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(0)), ((byte)(0)), ((byte)(0))), 8F, NxtControl.Drawing.DashStyle.Solid);
			this.polyline2.Points.AddRange(new NxtControl.Drawing.PointF[] {
									new NxtControl.Drawing.PointF(180D, 243D),
									new NxtControl.Drawing.PointF(180D, 206D),
									new NxtControl.Drawing.PointF(79D, 206D),
									new NxtControl.Drawing.PointF(79D, 167D)});
			// 
			// rectangle1
			// 
			this.rectangle1.Bounds = new NxtControl.Drawing.RectF(((float)(57D)), ((float)(367D)), ((float)(256D)), ((float)(140D)));
			this.rectangle1.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.rectangle1.Name = "rectangle1";
			// 
			// freeText1
			// 
			this.freeText1.Color = new NxtControl.Drawing.Color("Red");
			this.freeText1.Font = new NxtControl.Drawing.Font("LabelFont");
			this.freeText1.Location = new NxtControl.Drawing.PointF(175D, 376D);
			this.freeText1.Name = "freeText1";
			this.freeText1.Text = "HMI";
			// 
			// START_BT
			// 
			this.START_BT.BeginInit();
			this.START_BT.AngleIgnore = false;
			this.START_BT.DesignTransformation = new NxtControl.Drawing.Matrix(1D, 0D, 0D, 1D, 73D, 416D);
			this.START_BT.Name = "START_BT";
			this.START_BT.SecurityToken = ((uint)(4294967295u));
			this.START_BT.TagName = "DA035AD46AE24B5";
			this.START_BT.EndInit();
			// 
			// freeText2
			// 
			this.freeText2.Color = new NxtControl.Drawing.Color("Blue");
			this.freeText2.Font = new NxtControl.Drawing.Font("LabelFont");
			this.freeText2.Location = new NxtControl.Drawing.PointF(72D, 462D);
			this.freeText2.Name = "freeText2";
			this.freeText2.Text = "START";
			// 
			// HMI1
			// 
			this.HMI1.BeginInit();
			this.HMI1.AngleIgnore = false;
			this.HMI1.DesignTransformation = new NxtControl.Drawing.Matrix(1D, 0D, 0D, 1D, 165D, 418D);
			this.HMI1.Name = "HMI1";
			this.HMI1.SecurityToken = ((uint)(4294967295u));
			this.HMI1.TagName = "5119F5BF715BCD1A";
			this.HMI1.EndInit();
			// 
			// freeText3
			// 
			this.freeText3.Color = new NxtControl.Drawing.Color("Blue");
			this.freeText3.Font = new NxtControl.Drawing.Font("LabelFont");
			this.freeText3.Location = new NxtControl.Drawing.PointF(145D, 463D);
			this.freeText3.Name = "freeText3";
			this.freeText3.Text = "AUTOMATIC";
			// 
			// freeText5
			// 
			this.freeText5.Color = new NxtControl.Drawing.Color("Blue");
			this.freeText5.Font = new NxtControl.Drawing.Font("LabelFont");
			this.freeText5.Location = new NxtControl.Drawing.PointF(151D, 476D);
			this.freeText5.Name = "freeText5";
			this.freeText5.Text = "CONTROL";
			// 
			// Stop_Button
			// 
			this.Stop_Button.BeginInit();
			this.Stop_Button.AngleIgnore = false;
			this.Stop_Button.DesignTransformation = new NxtControl.Drawing.Matrix(1D, 0D, 0D, 1D, 251D, 418D);
			this.Stop_Button.Name = "Stop_Button";
			this.Stop_Button.SecurityToken = ((uint)(4294967295u));
			this.Stop_Button.TagName = "15B71BB10B1899B";
			this.Stop_Button.EndInit();
			// 
			// freeText6
			// 
			this.freeText6.Color = new NxtControl.Drawing.Color("Blue");
			this.freeText6.Font = new NxtControl.Drawing.Font("LabelFont");
			this.freeText6.Location = new NxtControl.Drawing.PointF(232D, 463D);
			this.freeText6.Name = "freeText6";
			this.freeText6.Text = "EMERGENCY";
			// 
			// freeText7
			// 
			this.freeText7.Color = new NxtControl.Drawing.Color("Blue");
			this.freeText7.Font = new NxtControl.Drawing.Font("LabelFont");
			this.freeText7.Location = new NxtControl.Drawing.PointF(251D, 476D);
			this.freeText7.Name = "freeText7";
			this.freeText7.Text = "STOP";
			// 
			// Canvas1
			// 
			this.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(800D)), ((float)(520D)));
			this.Brush = new NxtControl.Drawing.Brush("CanvasBrush");
			this.Name = "Canvas1";
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
									this.Cylinder,
									this.polyline1,
									this.polyline2,
									this.rectangle1,
									this.freeText1,
									this.START_BT,
									this.freeText2,
									this.HMI1,
									this.freeText3,
									this.freeText5,
									this.Stop_Button,
									this.freeText6,
									this.freeText7});
			this.Size = new System.Drawing.Size(800, 520);
		}
		private NxtControl.GuiFramework.FreeText freeText7;
		private NxtControl.GuiFramework.FreeText freeText6;
		private HMI.Main.Symbols.CallButton.sDefault Stop_Button;
		private NxtControl.GuiFramework.FreeText freeText5;
		private NxtControl.GuiFramework.FreeText freeText3;
		private HMI.Main.Symbols.CallButton.sDefault HMI1;
		private NxtControl.GuiFramework.FreeText freeText2;
		private HMI.Main.Symbols.CallButton.sDefault START_BT;
		private NxtControl.GuiFramework.FreeText freeText1;
		private NxtControl.GuiFramework.Rectangle rectangle1;
		private NxtControl.GuiFramework.Polyline polyline2;
		private NxtControl.GuiFramework.Polyline polyline1;
		private HMI.Main.Symbols.CylinderLS.sDefault Cylinder;
		#endregion
	}
}
