using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region CallButton_HMI;
#endregion CallButton_HMI;

#endregion Definitions;

