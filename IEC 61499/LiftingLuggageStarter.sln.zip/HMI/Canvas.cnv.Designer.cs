﻿/*
 * Created by nxtSTUDIO.
 * User: valeriy
 * Date: 7/21/2018
 * Time: 9:19 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;

using NxtControl.GuiFramework;

namespace HMI.Main.Canvases
{
	/// <summary>
	/// Summary description for Canvas2.
	/// </summary>
	partial class Canvas
	{
		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Model = new HMI.Main.Symbols.Model.sDefault();
			this.CP = new HMI.Main.Symbols.ControlPanel.sDefault();
			// 
			// Model
			// 
			this.Model.BeginInit();
			this.Model.AngleIgnore = false;
			this.Model.DesignTransformation = new NxtControl.Drawing.Matrix(1D, 0D, 0D, 1D, -2D, 6D);
			this.Model.Name = "Model";
			this.Model.SecurityToken = ((uint)(4294967295u));
			this.Model.TagName = "C00843860ECF7B6C";
			this.Model.EndInit();
			// 
			// CP
			// 
			this.CP.BeginInit();
			this.CP.AngleIgnore = false;
			this.CP.DesignTransformation = new NxtControl.Drawing.Matrix(1D, 0D, 0D, 1D, 65D, 520D);
			this.CP.Name = "CP";
			this.CP.SecurityToken = ((uint)(4294967295u));
			this.CP.TagName = "E42D03E45598A501";
			this.CP.EndInit();
			// 
			// Canvas
			// 
			this.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(590D)), ((float)(565D)));
			this.Brush = new NxtControl.Drawing.Brush("CanvasBrush");
			this.Name = "Canvas2";
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
									this.Model,
									this.CP});
			this.Size = new System.Drawing.Size(590, 565);
		}
		private HMI.Main.Symbols.ControlPanel.sDefault CP;
		private HMI.Main.Symbols.Model.sDefault Model;
		#endregion
	}
}
